<?php
/* Paypal Zahlung erfolgt */
?>