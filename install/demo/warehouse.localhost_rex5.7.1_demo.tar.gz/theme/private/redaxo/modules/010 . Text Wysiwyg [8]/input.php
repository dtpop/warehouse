<fieldset class="form-horizontal">
    <legend>Text</legend>
    <div class="form-group">
        <label class="col-sm-2 control-label" for="text">Text</label>
        <div class="col-sm-10">
            <textarea cols="1" rows="6" id="text" class="form-control tinyMCE-text" name="REX_INPUT_VALUE[1]">REX_VALUE[1]</textarea>
        </div>
    </div>    
</fieldset>
