<?php
/* -- 900 . PHP -- */

// Artikel Parameter
$siteStartArticle  = rex_article::getSiteStartArticleId();
$currentArtikelId  = rex_article::getCurrentId();
$notfoundArticleId = rex_article::getNotfoundArticleId();
$artikelStatus     = rex_article::getCurrent()->getValue( 'status' );
$currentUrl        = rex_yrewrite::getFullUrlByArticleId( $currentArtikelId );
$seo               = new rex_yrewrite_seo();


function shopmenu ($cat) {
    $menutype = explode('|',trim($cat->getValue('cat_menu_type'),'|'));
    if (in_array(2,$menutype)) {
        $fragment = new rex_fragment();
        $fragment->setVar('ul_class','uk-nav uk-navbar-dropdown-nav');
        $fragment->setVar('wrapper',['<div class="uk-navbar-dropdown">','</div>']);
        return $fragment->parse('wh_shop_menu.php');
    } else {
        return '';
    }
}

function mobile_shopmenu ($cat) {
    $menutype = explode('|',trim($cat->getValue('cat_menu_type'),'|'));
    if (in_array(2,$menutype)) {
        $fragment = new rex_fragment();
        $fragment->setVar('ul_class','uk-list-divider');
        $fragment->setVar('wrapper',['','']);
        return $fragment->parse('wh_shop_menu.php');
    } else {
        return '';
    }
}

$mainnav = new wh_nav();
$mainnav->ulClasses = ['uk-navbar-nav','uk-nav uk-navbar-dropdown-nav',''];
$mainnav->dataAttribute = ['uk-navbar="offset: 0"',''];
$mainnav->fullTree = 1;
$mainnav->func_li_end = 'shopmenu';
$mainnav->ulWrapper = ['',['<div class="uk-navbar-dropdown">','</div>']];
$mainnav->metaField = 'cat_menu_type';
$mainnav->metaValue = 1;

$mobilenav = new wh_nav();
// $mobilenav->dataAttribute = ['uk-navbar="offset: 0"',''];
$mobilenav->fullTree = 1;
$mobilenav->func_li_end = 'mobile_shopmenu';
// $mobilenav->ulWrapper = [];
// $mobilenav->liClasses = ['uk-margin-remove uk-padding-remove','uk-margin-remove uk-padding-remove'];
$mobilenav->ulClasses = ['uk-nav uk-list-divider lev1','uk-list-divider lev2',''];
$mobilenav->metaField = 'cat_menu_type';
$mobilenav->metaValue = 1;

$footernav = new wh_nav();
$footernav->fullTree = 1;
$footernav->metaField = 'cat_menu_type';
$footernav->metaValue = 4;
$footernav->ulClasses = ['uk-grid'];

$wh_prop = rex::getProperty('wh_prop');
$wh_cart = warehouse::get_cart();

$to_cart_link = rex_config::get('warehouse','cart_mode') == 'cart' ? rex_getUrl(rex_config::get('warehouse','cart_page')) : '#cart-offcanvas';



// $nav = rex_navigation::factory();




?>
