$(function () {    
    
    $('label.switch_count').click(function() {
        var for_id = $(this).attr('for');
        var cur_val = $('input#'+for_id).val();
        var new_val = eval(cur_val + $(this).data('value'));
        if (new_val < 1) {
            new_val = 1;
        }
        $('input#'+for_id).val(new_val);
    });    

});