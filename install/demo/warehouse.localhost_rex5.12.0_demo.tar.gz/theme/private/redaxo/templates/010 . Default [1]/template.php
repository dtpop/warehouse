REX_TEMPLATE[id=2 name=php]
<!DOCTYPE html>
<html>
    <head>
        <?= $seo->getTitleTag(); ?>
        <?= $seo->getRobotsTag(); ?>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/theme/public/assets/frontend/css/uikit.min.css" />
        <link rel="stylesheet" href="/theme/public/assets/frontend/css/wh_custom.css" />
        <link rel="stylesheet" href="/theme/public/assets/frontend/styles/style.css" />
    </head>
    <body>
        
        
        <header>
            <div uk-sticky="sel-target: .page-header; bottom: true;cls-active: is-sticky;show-on-up: true;animation: uk-animation-slide-top">
                <nav class="uk-navbar-container">
                    <div class="uk-container">
                        <div class="uk-navbar-left">
                            <a class="uk-hidden@m uk-padding" uk-toggle="target: #nav-offcanvas">
                                <span uk-icon="icon: menu; ratio: 2"></span>
                            </a>            
                            <a class="uk-navbar-item uk-logo" href="<?= rex_article::getSiteStartArticle()->getUrl() ?>"><img src="/assets/addons/warehouse/images/logo_wh.svg" class="wh_logo"></a>
                            <div class="uk-visible@m" id="main_nav">
                                <?= $mainnav->getNavigation(); ?>
                            </div>
                            <?php if (rex_plugin::get('ycom','auth')->isAvailable()) : ?>
                                <div class="uk-navbar-right">
                                    <ul class="uk-navbar-nav">
                                        <?php if ($ycom_user) : ?>
                                            <li><a href="<?= rex_getUrl(24) ?>"><?= $ycom_user->getValue('firstname') ?></a></li>
                                            <li><a href="<?= rex_getUrl(23) ?>">Logout</a></li>
                                        <?php else : ?>
                                            <li><a href="<?= rex_getUrl(rex_config::get('ycom/auth','article_id_login')) ?>">Login</a></li>
                                            <li><a href="<?= rex_getUrl(rex_config::get('ycom/auth','article_id_register')) ?>">Registrieren</a></li>
                                        <?php endif ?>
                                    </ul>                                
                                </div>
                            <?php endif ?>
                            
                            <a class="uk-icon-link cart_link uk-align-right uk-margin-right uk-margin-top" uk-icon="cart" href="<?= $to_cart_link ?>" uk-toggle>
                                <?php if (count($wh_cart)) : ?>
                                    <div class="circle cart_count"><?= count($wh_cart) ?></div>
                                <?php endif ?>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        
        <section>
            <article class="uk-container uk-padding">
                <div>
                    <?php if (count($wh_prop['path'])) : ?>
                        <ul class="uk-breadcrumb">
                            <li><a href="<?= rex_getUrl() ?>"><?= rex_article::getCurrent()->getName() ?></a></li>
                            <?php foreach ($wh_prop['path'] as $seg) : ?>
                                <li>
                                    <a href="<?= rex_getUrl('','',['category_id'=>$seg['id']]) ?>"><?= $seg['name'] ?></a>
                                </li>
                            <?php endforeach ?>
                        </ul>
                    <?php endif ?>
                </div>                
                REX_ARTICLE[]
                <!-- pre>
                <?php // print_r($wh_prop); ?>
                <?php // print_r($wh_cart); ?>
                </pre -->
            </article>
        </section>
        
        <footer class="uk-background-secondary">
            <section class="uk-container uk-padding">
                <nav>
                    <?= $footernav->getNavigation(); ?>
                </nav>                
            </section>            
        </footer>
        
        <?php /* -- Offcanvas Warenkorb -- */ ?>
        <?php $fragment = new rex_fragment() ?>
        <?php $fragment->setVar('cart',$wh_cart); ?>
        <?php echo $fragment->parse('wh_offcanvas_cart.php'); ?>
        
        
        <?php /* -- Mobiles Menü -- */ ?>
       <div id="nav-offcanvas" uk-offcanvas="">
            <aside class="uk-padding-remove uk-offcanvas-bar uk-card-small uk-card">
                <div class="uk-card-header">
                    <a class="uk-margin-auto-left uk-offcanvas-close" type="button" uk-close="ratio: 1.5"></a>
                </div>
                <div class="uk-card-small uk-card-body uk-padding-small-top">
                    <?= $mobilenav->getNavigation(); ?>
                </div>
            </aside>
        </div>
    
        
        
        
        <?php /* -- Versandkosten Modal -- */ ?>
        <div id="shipping_modal" uk-modal>
            <div class="uk-modal-dialog uk-modal-body">
                <button class="uk-modal-close-default" type="button" uk-close></button>
                <h2 class="uk-modal-title">Versandkosten</h2>
                <?php echo $fragment->parse('wh_shipping_cost.php'); ?>
                <?php // dump(rex_config::get('warehouse','shipping_mode')); ?>
                <?php // dump(json_decode(rex_config::get('warehouse','shipping_parameters'))); ?>
            </div>
        </div>        


        <script src="/theme/public/assets/frontend/js/jquery-3.3.1.min.js"></script>
        <script src="/theme/public/assets/frontend/js/uikit.min.js"></script>
        <script src="/theme/public/assets/frontend/js/uikit-icons.min.js"></script>
        <script src="/assets/addons/warehouse/scripts/wh_scripts.js"></script>
        <?php if (rex_get('showcart','int')) : ?>
        <script>
                UIkit.offcanvas('#cart-offcanvas').show();
        </script>
        <?php endif ?>
        <?= rex::getProperty('js',''); ?>
    </body>
</html>